import Ember from 'ember';
/* global _ */

export default Ember.Component.extend({

  classNames: ['corpus'],
  selectAll: true,

  numberOfLanguagesClasses: Ember.computed('numberOfLanguages', function() {
    switch (this.get("numberOfLanguages")) {
      case 1: return "one";
      case 2: return "two";
      case 3: return "three";
      case 4: return "four";
      case 5: return "five";
      default: return "three";
    }
  }),

  adultFilterOptions: Ember.computed("corpus.adultFilter", function() {
    var adultFilter = this.get("corpus.adultFilter.id");

    return [
      Ember.Object.create({id: 'Moderate', name: 'Moderate', selected: adultFilter === "Moderate" ? true : false}),
      Ember.Object.create({id: 'Strict', name: 'Strict', selected: adultFilter === "Strict" ? true : false}),
      Ember.Object.create({id: 'Off', name: 'Off', selected: adultFilter === "Off" ? true : false})
    ];
  }),

  nResultsOptions: Ember.computed("corpus.nResults", function() {
    var nResults = this.get("corpus.nResults.id");

    return [
      Ember.Object.create({id: '10', name: '10', selected: nResults === "10" ? true : false}),
      Ember.Object.create({id: '20', name: '20', selected: nResults === "20" ? true : false}),
      Ember.Object.create({id: '30', name: '30', selected: nResults === "30" ? true : false}),
      Ember.Object.create({id: '40', name: '40', selected: nResults === "40" ? true : false}),
      Ember.Object.create({id: '50', name: '50', selected: nResults === "50" ? true : false})
    ];
  }),

  languageOptions: Ember.computed("corpus.language", function() {
    var lang = this.get("corpus.language.id");

    return [
      Ember.Object.create({id: 'en', name: 'English', selected: lang === "en" ? true : false}),
      Ember.Object.create({id: 'pt', name: 'Portuguese', selected: lang === "pt" ? true : false}),
      Ember.Object.create({id: 'es', name: 'Spanish', selected: lang === "es" ? true : false}),
      Ember.Object.create({id: 'it', name: 'Italian', selected: lang === "it" ? true : false}),
      Ember.Object.create({id: 'fr', name: 'French', selected: lang === "fr" ? true : false}),
      Ember.Object.create({id: 'de', name: 'German', selected: lang === "de" ? true : false}),
      Ember.Object.create({id: 'nl', name: 'Dutch', selected: lang === "nl" ? true : false}),
      Ember.Object.create({id: 'da', name: 'Danish', selected: lang === "da" ? true : false}),
      Ember.Object.create({id: 'fi', name: 'Finish', selected: lang === "fi" ? true : false}),
      Ember.Object.create({id: 'zh', name: 'Chinese', selected: lang === "zh" ? true : false}),
      Ember.Object.create({id: 'ja', name: 'Japanese', selected: lang === "ja" ? true : false}),
      Ember.Object.create({id: 'ko', name: 'Korean', selected: lang === "ko" ? true : false}),
      Ember.Object.create({id: 'no', name: 'Norwegian', selected: lang === "no" ? true : false}),
      Ember.Object.create({id: 'pl', name: 'Polish', selected: lang === "pl" ? true : false}),
      Ember.Object.create({id: 'ru', name: 'Russian', selected: lang === "ru" ? true : false}),
      Ember.Object.create({id: 'ar', name: 'Arabic', selected: lang === "ar" ? true : false}),
      Ember.Object.create({id: 'sv', name: 'Swedish', selected: lang === "sv" ? true : false}),
      Ember.Object.create({id: 'tr', name: 'Turkish', selected: lang === "tr" ? true : false}),
    ];
  }),

  /*
  es-AR, es-CL, es-MX, es-ES, es-US
  en-AU, en-CA, en-IN, en-ID, en-IE, en-MY, en-NZ, en-PH, en-ZA, en-GB, en-US
  de-AT, de-DE, de-CH,
  nl-BE, nl-NL,
  fr-BE, fr-CA, fr-FR, fr-CH,
  pt-BR, pt-PT,
  da-DK,
  fi-FI,
  zh-HK, zh-CN, zh-TW
  it-IT,
  ja-JP,
  ko-KR,
  no-NO,
  pl-PL,
  ru-RU,
  ar-SA,
  sv-SE,
  tr-TR,
  */

  countryOptions: Ember.computed('corpus.language', 'corpus.country', function() {
    var countries = [];
    var lang = this.get("corpus.language.id");
    var country = this.get("corpus.country.id");

    switch (lang) {
      case "en": countries = [
        Ember.Object.create({id: 'en-GB', name: 'United Kingdom', selected: country === "en-GB"}),
        Ember.Object.create({id: 'en-US', name: 'United States', selected: country === "en-US"}),
        Ember.Object.create({id: 'en-ZA', name: 'South Africa', selected: country === "en-ZA"}),
        Ember.Object.create({id: 'en-PH', name: 'Phillippines', selected: country === "en-PH"}),
        Ember.Object.create({id: 'en-NZ', name: 'New Zealand', selected: country === "en-NZ"}),
        Ember.Object.create({id: 'en-IE', name: 'Ireland', selected: country === "en-IE"}),
        Ember.Object.create({id: 'en-CA', name: 'Canada', selected: country === "en-CA"}),
        Ember.Object.create({id: 'en-IN', name: 'India', selected: country === "en-IN"}),
        Ember.Object.create({id: 'en-AU', name: 'Australia', selected: country === "en-AU"})
      ]; break;
      case "pt": countries = [
        Ember.Object.create({id: 'pt-PT', name: 'Portugal', selected: country === "pt-PT"}),
        Ember.Object.create({id: 'pt-BR', name: 'Brazil', selected: country === "pt-BR"})
      ]; break;
      case "es": countries = [
        Ember.Object.create({id: 'es-ES', name: 'Spain', selected: country === "es-ES"}),
        Ember.Object.create({id: 'es-AR', name: 'Argentina', selected: country === "es-AR"}),
        Ember.Object.create({id: 'es-MX', name: 'Mexico', selected: country === "es-MX"}),
        Ember.Object.create({id: 'es-CL', name: 'Chile', selected: country === "es-CL"}),
        Ember.Object.create({id: 'es-US', name: 'United States', selected: country === "es-US"})
      ]; break;
      case "it": countries = [Ember.Object.create({id: 'it-IT', name: 'Italia', selected: country === "it-IT"})]; break;
      case "fr": countries = [
        Ember.Object.create({id: 'fr-FR', name: 'France', selected: country === "fr-FR"}),
        Ember.Object.create({id: 'fr-BE', name: 'Belgium', selected: country === "fr-BE"}),
        Ember.Object.create({id: 'fr-CA', name: 'Canada', selected: country === "fr-CA"}),
        Ember.Object.create({id: 'fr-CH', name: 'Switzerland', selected: country === "fr-CH"})
      ]; break;
      case "de": countries = [
        Ember.Object.create({id: 'de-DE', name: 'Germany', selected: country === "de-DE"}),
        Ember.Object.create({id: 'de-AT', name: 'Austria', selected: country === "de-AT"}),
        Ember.Object.create({id: 'de-CH', name: 'Switzerland', selected: country === "de-CH"})
      ]; break;
      case "nl": countries = [
        Ember.Object.create({id: 'nl-NL', name: 'Netherlands', selected: country === "nl-NL"}),
        Ember.Object.create({id: 'nl-BE', name: 'Belgium', selected: country === "nl-BE"})
      ]; break;
      case "da": countries = [Ember.Object.create({id: 'da-DK', name: 'Denmark', selected: country === "da-DK"})]; break;
      case "fi": countries = [Ember.Object.create({id: 'fi-FI', name: 'Finland', selected: country === "fi-FI"})]; break;
      case "zh": countries = [
        Ember.Object.create({id: 'zh-HK', name: 'Hong Kong', selected: country === "zh-HK"}),
        Ember.Object.create({id: 'zh-CN', name: 'Chinese', selected: country === "zh-CH"}),
        Ember.Object.create({id: 'zh-TW', name: 'Taiwan', selected: country === "zh-TW"})
      ]; break;
      case "ja": countries = [Ember.Object.create({id: 'ja-JP', name: 'Japan', selected: country === "ja-JP"})]; break;
      case "ko": countries = [Ember.Object.create({id: 'ko-KR', name: 'Korea', selected: country === "ko-KO"})]; break;
      case "no": countries = [Ember.Object.create({id: 'no-NO', name: 'Norway', selected: country === "no-NO"})]; break;
      case "pl": countries = [Ember.Object.create({id: 'pl-PL', name: 'Poland', selected: country === "pl-PL"})]; break;
      case "ru": countries = [Ember.Object.create({id: 'ru-RU', name: 'Russia', selected: country === "ru-RU"})]; break;
      case "ar": countries = [Ember.Object.create({id: 'ar-SA', name: 'Saudi Arabia', selected: country === "ar-SA"})]; break;
      case "sv": countries = [Ember.Object.create({id: 'sv-SE', name: 'Sweden', selected: country === "sv-SE"})]; break;
      case "tr": countries = [Ember.Object.create({id: 'tr-TR', name: 'Turkey', selected: country === "tr-TR"})]; break;
      default: countries = []; break;
    }

    var selected = _.find(countries, (c) => {return c.selected;});
    if(selected === undefined && countries.length > 0) {
      countries[0].selected = true;
      this.set("corpus.country", countries[0]);
    }

    return countries;
  }),

  selectedURLs: Ember.computed.filterBy('corpus.urls', 'selected', true),

  selectAllChanged: Ember.observer('selectAll', function() {
    _.each(this.get("corpus.urls"), (url) => {Ember.set(url, 'selected', this.get("selectAll"));});
  }),

  selectAllText: Ember.computed('selectAll', function() {
    return this.get("selectAll") ? "Deselect All" : "Select All";
  }),

});
