import Ember from 'ember';

export default Ember.Component.extend({

  classNames: ['drop-down'],
  classNameBindings: ['disabled:disabled'],

  selectedOptionChanged: Ember.observer('selectedOption', function() {
    this.get("options").forEach(option => {
      option.set("selected", this.get("selectedOption.id") === option.get("id") ? true : false);
    });
  }),

  actions: {
    select: function(id) {
      var option = _.find(this.get("options"), (op) => {return op.id + '' === id + '';});
      this.set("selectedOption", option);
    }
  }
});
