import Ember from 'ember';

export default Ember.Component.extend({
  classNames: ['load-spin'],
  classNameBindings: ['isLoading:display:no-display']
});
