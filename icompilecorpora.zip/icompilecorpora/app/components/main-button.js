import Ember from 'ember';

export default Ember.Component.extend({

  classNames: ['main-button'],
  classNameBindings: ['secondary:secondary', 'disabled:disabled', 'small:small'],

  actions: {
    mainAction: function() {
      this.sendAction();
    }
  }
});
