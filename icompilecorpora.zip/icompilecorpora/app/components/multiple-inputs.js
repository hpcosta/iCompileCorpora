import Ember from 'ember';
/* global _ */

export default Ember.Component.extend({
  classNames: ['multiple-inputs'],

  inputsChanged: Ember.observer('inputs', 'values', function() {
    if(this.get("inputs") !== undefined && this.get("values") !== undefined) {
      Ember.run.once(this, 'setValues');
    }
  }),

  setValues() {
    _.each(this.get("inputs"), (inp, i) => {
      if(this.get("values")[i] !== undefined) {
        Ember.set(inp, 'value', this.get("values")[i].value);
      }

    });
  },

  actions: {
    add: function() {
      this.get("inputs").pushObject(Ember.Object.create());
    },

    remove: function(input) {
      this.get("inputs").removeObject(input);

      if(this.get("inputs.length") === 0) {
        this.send('add');
      }
    },

    removeAll: function() {
      this.get("inputs").clear();
      this.send('add');
    }
  }
});
