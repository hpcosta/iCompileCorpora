import Ember from 'ember';

export default Ember.Component.extend({

  percentage: Ember.computed('value', 'total', function() {
    return (this.get("value") / this.get("total")) * 100;
  }),

  percentageStyle: Ember.computed('percentage', function() {
    return Ember.String.htmlSafe("width: " + this.get("percentage") + "%");
  })
});
