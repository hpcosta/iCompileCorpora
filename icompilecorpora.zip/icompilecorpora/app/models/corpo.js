import Ember from 'ember';

export default Ember.Object.extend({
  language: 'en',
  country: 'en-GB',
  formInvalid: false,

});
