import Ember from 'ember';

export default Ember.Object.extend({
  id: 'corpora',
  projectName: '',
  corpusType: 'Comparable',
  numberOfLanguages: 1,
  accountKey: '',
  corpora: [],

  formInvalid: false,

  numberOfLanguagesOptions: Ember.computed('numberOfLanguages', function() {
    var lang = this.get("numberOfLanguages.id");

    var options = [
      Ember.Object.create({name: "1", id: 1, selected: lang === 1 ? true : false}),
      Ember.Object.create({name: "2", id: 2, selected: lang === 2 ? true : false}),
      Ember.Object.create({name: "3", id: 3, selected: lang === 3 ? true : false}),
      Ember.Object.create({name: "4", id: 4, selected: lang === 4 ? true : false}),
      Ember.Object.create({name: "5", id: 5, selected: lang === 5 ? true : false})
    ];

    var selected = _.find(options, (op) => {return op.selected;});
    if(selected === undefined && options.length > 0) {
      options[0].selected = true;
      this.set("numberOfLanguages", options[0]);
    }

    return options;
  }),

});
