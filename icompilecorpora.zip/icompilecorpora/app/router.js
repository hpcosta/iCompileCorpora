import Ember from 'ember';
import config from './config/environment';

const Router = Ember.Router.extend({
  location: config.locationType
});

Router.map(function() {
  this.route('home');
  this.route('project', {path: '/project/:id'});
  this.route('corpora-definition', {path: '/corpora-definition/:id'});
  this.route('queries', {path: '/queries/:id'});
  this.route('search-restrictions', {path: '/search-restrictions/:id'});
  this.route('search-results', {path: '/search-results/:id'});
});

export default Router;
