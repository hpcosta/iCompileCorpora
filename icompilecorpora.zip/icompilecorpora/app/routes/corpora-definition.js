import Ember from 'ember';
/* global _ */

export default Ember.Route.extend({

  storage: Ember.inject.service('session-storage'),

  model(params) {
    return this.get("storage").getItem(params.id);
  },

  afterModel(model) {
    this.set("model", model);
  },

  getRandom(length) {
    return Math.floor(Math.random() * length);
  },

  generateQueries(callback) {
    var queries = [];
    var operators = ["AND", "OR", "NOT"];

    _.each(this.get("model.corpora"), (corpo) => {
      var seeds = _.filter(corpo.seeds, (seed) => {return seed.value !== "";});

      do {
        var query = '( ';

        _.each(_.shuffle(seeds), (seed, j) => {
          query += seed.value + " ";

          if(j < seeds.length - 1) {
            query += operators[this.getRandom(operators.length)] + " ";
          }
        });

        if(!_.contains(queries, query)) {
          query += " )";
          queries.pushObject(query);
        }

      } while(queries.length < Math.min(5, Math.pow(seeds.length, operators.length)));

      //empty query
      queries.pushObject("");

      Ember.set(corpo, "queries", _.map(queries, (q) => {return {value: q};}));
      queries = [];
    });

    callback();
  },

  actions: {
    error(error) {
      if (error) {
        return this.transitionTo('home');
      }
    },

    next() {
      this.get("storage").save('corpora', this.get("model"));
      this.generateQueries(() => {
        this.transitionTo('queries', this.get("model"));
      });
    },

    back() {
      this.get("storage").save('corpora', this.get("model"));
      this.transitionTo('project', this.get("model"));
    }

  },

});
