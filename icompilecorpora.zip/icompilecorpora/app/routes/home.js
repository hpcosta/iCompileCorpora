import Ember from 'ember';
import Corpora from '../models/corpora';

export default Ember.Route.extend({

  storage: Ember.inject.service('session-storage'),

  actions: {
    startProject: function() {
      var corpora = Corpora.create({id: 'corpora', corpusType: 'Comparable', numberOfLanguages: Ember.Object.create({id: 1, name: "1", selected: true})});

      this.get("storage").remove('corpora');
      this.get("storage").save('corpora', corpora);
      this.transitionTo('project', corpora);
    }
  }

});
