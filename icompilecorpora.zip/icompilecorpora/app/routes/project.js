import Ember from 'ember';
import Corpo from '../models/corpo';

export default Ember.Route.extend({

  storage: Ember.inject.service('session-storage'),

  model(params) {
    return this.get("storage").getItem(params.id);
  },

  afterModel(model) {
    this.set("model", model);
  },

  formInvalid: Ember.computed('model.projectName', 'model.corpusType', 'model.numberOfLanguages', 'model.accountKey', function() {
    return Ember.isEmpty(this.get("model.projectName")) || Ember.isEmpty(this.get("model.corpusType")) || Ember.isEmpty(this.get("model.numberOfLanguages")) || Ember.isEmpty(this.get("model.accountKey"));
  }),

  createCorpora() {
    this.set("model.corpora", []);

    for(var i=1; i <= parseInt(this.get("model.numberOfLanguages.id")); i++) {
      var lang = Ember.Object.create({id: 'en', name: 'English', selected: true});
      var country = Ember.Object.create({id: 'en-GB', name: 'United Kingdom', selected: true});
      var adultFilter = Ember.Object.create({id: 'Moderate', name: 'Moderate', selected: true});
      var nResults = Ember.Object.create({id: '10', name: '10', selected: true});
      this.get("model.corpora").pushObject(Corpo.create({id: i, language: lang, country: country, adultFilter: adultFilter, nResults: nResults, seeds: [Ember.Object.create({value: ''}), Ember.Object.create({value: ''}), Ember.Object.create({value: ''})], limits: [ Ember.Object.create({value: '', placeholder: 'e.g. "wikipedia.com"'})], restrictions: [Ember.Object.create({value: '', placeholder: 'e.g. ".org"'})], queries: [Ember.Object.create({value: ''}), Ember.Object.create({value: ''}), Ember.Object.create({value: ''})]}));
    }
  },

  actions: {
    error(error) {
      if (error) {
        return this.transitionTo('home');
      }
    },

    next: function() {
      this.createCorpora();
      this.get("storage").save('corpora', this.get("model"));
      this.transitionTo('corpora-definition', this.get("model"));
    },

    back: function() {
      this.get("storage").save('corpora', this.get("model"));
      this.transitionTo('home');
    }
  }
});
