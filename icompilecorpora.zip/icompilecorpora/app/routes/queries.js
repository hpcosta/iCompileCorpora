import Ember from 'ember';

export default Ember.Route.extend({

  storage: Ember.inject.service('session-storage'),

  model(params) {
    return this.get("storage").getItem(params.id);
  },

  afterModel(model) {
    this.set("model", model);
  },

  actions: {
    error(error) {
      if (error) {
        return this.transitionTo('home');
      }
    },

    next: function() {
      this.get("storage").save('corpora', this.get("model"));
      this.transitionTo('search-restrictions', this.get("model"));
    },

    back: function() {
      this.get("storage").save('corpora', this.get("model"));
      this.transitionTo('corpora-definition', this.get("model"));
    }
  },

});
