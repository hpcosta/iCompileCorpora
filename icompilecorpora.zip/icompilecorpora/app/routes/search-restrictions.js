import Ember from 'ember';

export default Ember.Route.extend({

  storage: Ember.inject.service('session-storage'),

  model(params) {
    return this.get("storage").getItem(params.id);
  },

  afterModel(model) {
    this.set("model", model);
    model.set("isLoading", false);
  },

  actions: {
    error(error) {
      if (error) {
        return this.transitionTo('home');
      }
    },

    search: function() {
      this.transitionTo('search-results', this.get("model"));
    },

    back: function() {
      this.get("storage").save('corpora', this.get("model"));
      this.transitionTo('queries', this.get("model"));
    }
  },

});
