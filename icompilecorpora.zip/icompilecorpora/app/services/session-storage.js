import Ember from 'ember';
import Corpora from '../models/corpora';

export default Ember.Service.extend({

  save(key, value) {
    if(value !== undefined) {
      sessionStorage.setItem(key, JSON.stringify(value));
    }
  },

  getItem(key) {
    var item = sessionStorage.getItem(key);

    if(item !== undefined) {
      return Corpora.create(JSON.parse(item));
    }
  },

  remove(key) {
    sessionStorage.removeItem(key);
  }

});
