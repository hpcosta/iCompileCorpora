var express = require('express');
var fs = require('fs');
var request = require('request');
var cheerio = require('cheerio');
var app     = express();

app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    //res.setHeader('Content-Type', 'application/zip')
    res.setHeader("content-disposition", "attachment; filename=output.html");

    // Pass to next layer of middleware
    next();
});

app.get('/scrape', function(req, res) {

    url = 'http://www.imdb.com/title/tt1229340/';
    //url = req.params.url;

    request(url, function(error, response, html) {
        if(!error) {
          fs.writeFile('output.html', html, function(err) {
              console.log('File successfully written! - Check your project directory for the output.json file');

              res.download('output.html');
              //res.send('ok!');
          });

          // Finally, we'll just send out a message to the browser reminding you that this app does not have a UI.


        } else {
          res.send(500);
        }

    });
});

app.listen('8081');
console.log('Magic happens on port 8081');
exports = module.exports = app;
