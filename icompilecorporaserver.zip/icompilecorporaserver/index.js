var express = require('express');
var bodyParser = require('body-parser');
var fs = require('fs');
var request = require('request');
var cheerio = require('cheerio');
var app     = express();
var JSZip = require("jszip");
var zip = new JSZip();
var path = path = require('path');

app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    res.setHeader('content-type', 'application/zip');


    // Pass to next layer of middleware
    next();
});

app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json());

app.post('/scrape', function(req, res) {

    var urls = req.body.urls !== undefined ? JSON.parse(req.body.urls) : [];
    var n = 0;
    for(var i=0; i<urls.length; i++) {
      console.log("URL: ", urls[i]);
      url = urls[i];

      request(url, function(error, response, html) {
          if(!error) {
            n++;
            console.log("HTML ", n);
            zip.file('output'+n+'.html', html);

            if(n === urls.length) {
              zip
              .generateNodeStream({type:'nodebuffer',streamFiles:true})
              .pipe(fs.createWriteStream('cenas.zip'))
              .on('finish', function () {
                  // JSZip generates a readable stream with a "end" event,
                  // but is piped here in a writable stream which emits a "finish" event.
                  console.log("out.zip written.");
                  /*fs.readFile('/Users/bfurtado/Documents/nodedevelopment/web-crawler/out.zip', (err, data) => {
                    console.log(data);
                    res.send(data);
                  });*/

                  var filepath = path.join(__dirname, 'cenas.zip');
                  var readStream = fs.createReadStream(filepath);
                  console.log(filepath);
                  // We replaced all the event handlers with a simple call to readStream.pipe()
                  readStream.on('data', function(data) {
                      res.write(data);
                  });

                  readStream.on('end', function() {
                      res.end();
                  });

              });

            }
            /*var $ = cheerio.load(html);

            var title, release, rating;
            var json = { title : "", release : "", rating : ""};

            $('.header').filter(function() {
                var data = $(this);
                title = data.children().first().text();

                release = data.children().last().children().text();

                json.title = title;
                json.release = release;
            });

            // Since the rating is in a different section of the DOM, we'll have to write a new jQuery filter to extract this information.

            $('.star-box-giga-star').filter(function() {
                var data = $(this);

                // The .star-box-giga-star class was exactly where we wanted it to be.
                // To get the rating, we can simply just get the .text(), no need to traverse the DOM any further

                rating = data.text();

                json.rating = rating;
            });*/
          }

          // To write to the system we will use the built in 'fs' library.
          // In this example we will pass 3 parameters to the writeFile function
          // Parameter 1 :  output.json - this is what the created filename will be called
          // Parameter 2 :  JSON.stringify(json, null, 4) - the data to write, here we do an extra step by calling JSON.stringify to make our JSON easier to read
          // Parameter 3 :  callback function - a callback function to let us know the status of our function

          /*fs.writeFile('output.html', html, function(err) {

              console.log('File successfully written! - Check your project directory for the output.json file');

          });*/

          // Finally, we'll just send out a message to the browser reminding you that this app does not have a UI.



      });


    }
});

app.listen('8081');
console.log('Magic happens on port 8081');
exports = module.exports = app;
