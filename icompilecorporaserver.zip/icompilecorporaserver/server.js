var express = require('express');
var request = require('request');
var cheerio = require('cheerio');
var app     = express();

app.use(function (req, res, next) {
    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*'); //http://localhost:4200 //https://icompilecorpora.herokuapp.com
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    res.setHeader('content-type', 'text/plain');

    next(); // Pass to next layer of middleware
});

app.get('/scrape/:url/:displayUrl', function(req, res) {
  url = decodeURIComponent(req.params.url);
  displayUrl = decodeURIComponent(req.params.displayUrl);

  request(url, function(error, response, html) {
      if(!error) {
        $ = cheerio.load(html);
        var pageURL = displayUrl + ' \n';
        var textPage = $('html *').contents().map(function() {
          return (this.type === 'text' && this.parent.type !== 'script' && this.parent.type !== 'style') ? $(this).text().trim()+' ' : '';
        }).get().join('');

        res.send(pageURL + textPage);
      }
  });

});

app.listen(process.env.PORT || 8081);
console.log('Magic happens on port ', process.env.PORT || 8081);
exports = module.exports = app;
